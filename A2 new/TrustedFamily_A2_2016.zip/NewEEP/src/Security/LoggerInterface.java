
package Security;

/**
 *
 * Interface for Logger
 */
public interface LoggerInterface {
    public void log(String s);
}
