echo "Starting rmiregistry" | rmiregistry | echo "Starting MessageManager" | java MessageManager
