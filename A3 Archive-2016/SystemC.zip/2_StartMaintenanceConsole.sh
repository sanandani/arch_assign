echo 'ECS Service Maintenance Console'
java ECSSrvcMaintainConsole
