
1. How to start system?
a) Open a command line prompt in this directory 
b) Compile all of the applications by typing: javac *.java
c) Type "rmic MessageManager" to build the MessageManager interface stubs.
d) Make sure that port 1099 is available on your system.
e) If you are running on a Mac, please run the shell scripts ("sh filname.sh") in sequence as indiated by file titles
   E.g. "1_StartMessageManager.sh" means this file should be run in 1st place;
   If you are running on Windows, please run the batch file ("filename.bat") in sequence as indicated by file titles
   E.g. "1_EMStart.bat" means this file should be run first;


When shutting down a MessageManager, exit the MessageManager command window and also exit the MessageManager registry command window. If you fail to remember to shut down the MessageManager registry, you will not be able to start the MessageManager again.



