echo 'Security Monitoring Console'
java SecurityConsole
