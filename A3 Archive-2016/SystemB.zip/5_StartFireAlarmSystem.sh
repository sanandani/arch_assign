echo "Starting Fire Alarm Controller" | java FireAlarmController | java SprinklerController | echo "Starting Fire Sensor" | java FireSensor | java FireAlarmMonitor
