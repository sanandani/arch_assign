echo 'ECS Monitoring Console'
java ECSConsole
